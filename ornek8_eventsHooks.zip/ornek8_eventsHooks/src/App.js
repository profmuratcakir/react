function App() {
  return (
    <div className="App">
     <h1>Hello React</h1>
     <p>React UI geliştirmek için kullanilan bir javascript kütüphanesidir</p>
    </div>
  );
}
export default App;
